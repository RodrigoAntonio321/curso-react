function DigaMeuNome(props){
    return(
        <div>
            <p>Fala aí {props.nome}, suave na nave?</p>
        </div>
    )
}

export default DigaMeuNome