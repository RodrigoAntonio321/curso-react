# Aulas sobre React - Prof. Anderson Vanin

![image](https://user-images.githubusercontent.com/53703505/189367840-18a81b31-2bff-4d18-920e-490e60de07f2.png)


Estas aulas são baseadas na playlist de Vídeos de Matheus Battisti do Canal Hora de Codar disponível em: https://www.youtube.com/watch?v=FXqX7oof0I4&list=PLnDvRpP8BneyVA0SZ2okm-QBojomniQVO

Alguns trechos do vídeo serão omitidos e as aulas condensadas para o formato das aulas presenciais. Então poderemos fazer de 2 a 3 vídeos dessa playlist em uma aula durante a semana

# Instruções:

- Tenha o node e npm instalados em sua máquina
- baixe os arquivos em uma pasta
- abra o diretório contendo os arquivos da aula específica no VSCODE
- Abra um terminal e digite: npm install
- Aguarde o término da instalação das dependências.
