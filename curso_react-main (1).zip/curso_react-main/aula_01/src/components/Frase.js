function Frase(){
    return(
        <div>
            <p>Este é um componente com uma frase</p>
        </div>
    )
}
export default Frase