import Frase from "./Frase"

function HelloWorld(){
    return(
        <div>
            <h1>Meu Primeiro Componente</h1>
            <Frase />
        </div>
    )
}

export default HelloWorld